import math

a = int(input())
d = math.sin(a)
z1 = (1-2*(d**2)/1+math.sin(2*a))
z2 = (1-math.tan(a)/1+math.tan(a))
print(z1)
print(z2)
