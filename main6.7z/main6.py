# Number 10
# S = input()
# S0 = input()
# b = S.replace("c", S0)
# print(b)

# Number 11
# S = input()
# S0 = input()
# if S.__contains__(S0):
#     print(S.replace(S0, ''))
# else:
#     if not S.__contains__(S0):
#         print(S)