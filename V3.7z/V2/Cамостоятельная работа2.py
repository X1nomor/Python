import math

y = int(input())
x = int(input())
z = int(input())
e = int(input())
a = math.sin(z)
c = math.cos(y)
v = abs(x)
b = y ** pow(v, 1/3) + (c ** 3) * (((abs(x - y)) * (1 + ((c ** 2)/math.sqrt(x + y))))/(e ** abs(x -y) + (x/2)))
print(b)