import math

a = -3
b = 3
h = 0.5
while a < b:
    Y=a*math.log(abs(a - 0.6))
    a += h
    print(Y)