import math

a = (-math.pi)/6
b = (math.pi)/6
n = 15
x = a
while x < b:
    F = math.tan(4*x+8)
    print('Значение аргумента c=', x, end="\t")
    print('Значение функции F=', F, end="\t")
    x += (b-a)/n
    print("\n")