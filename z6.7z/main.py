S = input()
S0 = input()
b = S.replace('c', S0)
print(b)