# №2
# a = str(input())
# print(a[4],a[5],a[6])
# print(a[-5],a[-4],a[-3])
# print(a[4:7])
# №3
# a = 'кот'
# print(a[2],a[1],a[0])
# №4
# a = ['cat', 'dog', 'rabbit', 'carrot']
# print(a[0], a[3])
# №5
# def sum_range(start, end):
#     a = 0
#     while a<100:
#         if start < end:
#             for i in range(end, start+1, 1):
#                 a += i
#         else:
#             for i in range(start, end+1, 1):
#                 a += i
#     print(a)
#
#
# while True:
#     try:
#         x = int(input())
#         y = int(input())
#         print(sum_range(x, y))
#     except ValueError:
#         break